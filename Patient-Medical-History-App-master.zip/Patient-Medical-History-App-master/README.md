# Patient-Medical-History-App
Patients can enter Medical History using a Web Application for Oral Surgeons

# How to Run
docker-compose up --build -d

then go to http://localhost:8087/
